<?php include('./partial_front/menu.php');
  
?>
    <!-- Navbar Section Ends Here -->

    <!-- fOOD sEARCH Section Starts Here -->
    <section class="food-search">
        <div class="container">
           <?php
           
           if(isset($_SESSION['order']))
            {
              echo $_SESSION['order'];
              unset($_SESSION['order']);

            }
            ?>
            <h2 class="text-center text-white">Fill this form to confirm your order.</h2>

    
            <form action="#" class="order" method="POST" >
                <fieldset>
                    <legend>Selected Food</legend>
                 <?php
               $id =$_GET['id'];
                    $sql ="SELECT * FROM tbl_food where id=$id";

$res=mysqli_query($conn, $sql);
if($res==true)
{
    $count=mysqli_num_rows($res);

if($count>0)
{
    //get value from data
    while($rows=mysqli_fetch_assoc($res))
{
   $id=$rows['id'];
   $title=$rows['title'];

    $price=$rows['price'];
     $image_name=$rows['image_name'];
?>
   
   <div class="food-menu-img">
                        <img src="<?php echo SITEURL; ?>images/food/<?php echo $image_name; ?>" alt="<?php echo $title; ?>" class="img-responsive img-curve">
                    </div>
    
                    <div class="food-menu-desc">
                        <input type="hidden" name="food" value=" <?php echo $title; ?>">
                        <input type="hidden" name="price" value="<?php echo $price; ?>">
                        <h3><?php echo $title; ?></h3>
                        <p class="food-price"><?php echo $price ; ?>rs</p>

                        <div class="order-label">Quantity</div>
                        <input type="number" name="qty" class="input-responsive" value="1" required>
                        
                    </div>
 
            
             <?php
}

?>

         
            <?php

}
else
{
    //msg Data is not available
    ?>
    <div class="error">Data is not Available</div>
    <?php

}
}
else
{?>

    <div class="error"> query not executed</div>
    <?php
}
?>

                </fieldset>
                
                <fieldset>
                    <legend>Delivery Details</legend>
                    <div class="order-label">Full Name</div>
                    <input type="text" name="cust_name" placeholder="E.g. Enter name " class="input-responsive" required>

                    <div class="order-label">Phone Number</div>
                    <input type="tel" name="cust_contact" placeholder="E.g. 9843xxxxxx" class="input-responsive" required>

                    <div class="order-label">Email</div>
                    <input type="email" name="cust_email" placeholder="E.g. hi@vinod19.com" class="input-responsive" required>

                    <div class="order-label">Address</div>
                    <textarea name="cust_address" rows="10" placeholder="E.g. Street, City, Country" class="input-responsive" required></textarea>

                    <input type="submit" name="submit" value="Confirm Order" class="btn btn-primary">
                </fieldset>

            </form>

            <?php
            
            if(isset($_POST['submit']))

            {
                
               
               $title1=$_POST['food'];
               $price1 = $_POST['price'];
               $qty = $_POST['qty'];
               $total = $price1 * $qty; //total = qty*price
               $status='Ordered'; // status of  delivery or not 
               $order_date=date('d-m-y , h-i-sa'); //datwe of order
               $cust_name=$_POST['cust_name'];
               $cust_contact=$_POST['cust_contact'];
               $cust_email=$_POST['cust_email'];
               $cust_address=$_POST['cust_address'];
                  
                 $sql1 = "INSERT INTO tbl_order SET 
                 food='$title1',
                 price='$price1',
                 qty='$qty',
                 total='$total',
                 order_date='$order_date',
                 status='$status',
                 cust_name='$cust_name',
                 cust_email='$cust_email',
                 cust_contact='$cust_contact',
                 cust_address='$cust_address'";

                 $res1=mysqli_query($conn, $sql1);

                 if($res1==true)
                 {
                     //it is executed
                     $_SESSION['order']=" <div class='success'>Order placed successfully</div>  ";
                 }
                 else
                 {
                       // it is not executed
                       
                     $_SESSION['order'] =" <div class='error'>Order not place successfully</div>";
                       
                 }



            }
            
            ?>

        </div>
    </section>
    <!-- fOOD sEARCH Section Ends Here -->

    <!-- social Section Starts Here -->
    <?php include('./partial_front/footer.php'); ?>
    <!-- footer Section Ends Here -->

</body>
</html>