<!--navbar section -->
<?php include('./partial_front/menu.php'); ?>
    <!-- Navbar Section Ends Here -->

    <!-- fOOD sEARCH Section Starts Here -->
    <section class="food-search text-center">
        <div class="container">
            
            <form action="<?php echo SITEURL; ?>food-search.php" method="POST">
                <input type="search" name="search" placeholder="Search for Food.." required>
                <input type="submit" name="submit" value="Search" class="btn btn-primary">
            </form>

        </div>
    </section>
    <!-- fOOD sEARCH Section Ends Here -->

    <!-- CAtegories Section Starts Here -->
    <section class="categories">
        <div class="container">
            <h2 class="text-center">Explore Foods</h2>
            <?php 
            
            //create qury for get category from database
              $sql = "SELECT * FROM tbl_category LIMIT 3";

              $res =mysqli_query($conn, $sql);

              $count=mysqli_num_rows($res);

              if($count>0)
              {
                  //get all value in while loop for aaray form
                while($rows=mysqli_fetch_assoc($res))
                {
                    //get value in variable
                     $id=$rows['id'];
                     $title=$rows['title'];
                     $image_name=$rows['image_name'];

                     ?>
                        <a href="<?php echo SITEURL; ?>/category-foods.php?id=<?php echo $id; ?>">
            <div class="box-3 float-container">
             
            <?php if($image_name=="")
              {
                //
                echo " <div class='error'>Image is not available</div>  ";
              }
              else
              {
                ?>
                
                <img src="<?php echo SITEURL; ?>images/category/<?php echo $image_name;?>" alt="Pizza" class="img-responsive img-curve">
               
               <?php
              }
              ?>
              
                <h3 class="float-text text-white"><?php echo $title ?></h3>
            </div>
            </a>
                     <?php

                }
              }
              else
              {
                  //data is not available
                $_session['upload']=" <div class='error'>There is not have any category </div>  ";
              }
            
            ?>
            
            <div class="clearfix"></div>
        </div>
    </section>
    <!-- Categories Section Ends Here -->

    <!-- fOOD MEnu Section Starts Here -->
    <section class="food-menu">
        <div class="container">
            <h2 class="text-center">Food Menu</h2>
            <?php

$sql ="SELECT * FROM tbl_food";

$res=mysqli_query($conn, $sql);
if($res==true)
{
    $count=mysqli_num_rows($res);

if($count>0)
{
    //get value from data
    while($rows=mysqli_fetch_assoc($res))
{
   $id=$rows['id'];
   $title=$rows['title'];
   $description=$rows['description'];
    $price=$rows['price'];
     $image_name=$rows['image_name'];
?>
   
    
 
             <div class="food-menu-box">
                 <div class="food-menu-img">
                     <img src="<?php echo SITEURL; ?>images/food/<?php echo $image_name;  ?>" alt="<?php echo $title; ?>" class="img-responsive img-curve">
                 </div>
 
                 <div class="food-menu-desc">
                     <h4><?php echo $title; ?></h4>
                     <p class="food-price"><?php echo $price; ?></p>
                     <p class="food-detail">
                       <?php echo $description; ?>
                     </p>
                     <br>
 
                     <a href="<?php echo SITEURL;  ?>order.php?id=<?php echo $id; ?>" class="btn btn-primary" >Order Now</a>
                 </div>
                 </div>
             <?php
}

?>

         
            <?php

}
else
{
    //msg Data is not available
    ?>
    <div class="error">Data is not Available</div>
    <?php

}
}
else
{?>

    <div class="error"> query not executed</div>
    <?php
}
?>

            <div class="clearfix"></div>
        </div>

        <p class="text-center">
            <a href="#">See All Foods</a>
        </p>
    </section>
    <!-- fOOD Menu Section Ends Here -->

   <?php include('./partial_front/footer.php'); ?>