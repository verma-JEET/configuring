<?php include('./partial_front/menu.php');
     $search =$_POST['search'];
?>
    <!-- Navbar Section Ends Here -->

    <!-- fOOD sEARCH Section Starts Here -->
    <section class="food-search text-center">
        <div class="container">
            
            <h2>Foods on Your Search <a href="#" class="text-white"><?php echo $search; ?></a></h2>

        </div>
    </section>
    <!-- fOOD SEARCH Section Ends Here -->


    <!-- fOOD MENU Section Starts Here -->
    <section class="food-menu">
        <div class="container">
            <h2 class="text-center">Food Menu</h2>
       <?php

       //create to query for search item

       $sql="SELECT * FROM tbl_food WHERE title LIKE '%$search%' or description LIKE '%$search%'";

       $res= mysqli_query($conn, $sql);
       
       if($res==true)
       {
         //get value in
         $count=mysqli_num_rows($res);

         if($count>0)
         {
             // data more than zero
             while($row=mysqli_fetch_assoc($res))
             {
                 $id =$row['id'];
                 $title =$row['title'];
                 $price =$row['price'];
                 $description =$row['description'];
                 $image_name =$row['image_name'];
                 ?>
                 <div class="food-menu-box">
                <div class="food-menu-img ">
                    <img src="<?php echo SITEURL; ?>images/food/<?php echo $image_name; ?>" alt="<?php echo $title; ?>" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc text-center">
                    <h4><?php echo $title; ?></h4>
                    <p class="food-price"><?php echo $price; ?>rs</p>
                    <p class="food-detail">
                    <?php echo $description; ?>
                    </p>
                  

                    <a href="#" class="btn btn-primary">Order Now</a>
                </div>
            </div>
                 <?php
             }
         }
         else
         {
           //data is not available
           ?>
           <div class="error">The Item you search is not available</div>
           <?php
         }

       }
       else
       {
          //send error messagequery not execute
          ?>
          <div class="error">Query is not executed</div>
          <?php

       }
 
       ?>

            <div class="clearfix"></div>

        </div>

    </section>
    <!-- fOOD Menu Section Ends Here -->

    <!-- social Section Starts Here -->
    <?php include('./partial_front/footer.php'); ?>