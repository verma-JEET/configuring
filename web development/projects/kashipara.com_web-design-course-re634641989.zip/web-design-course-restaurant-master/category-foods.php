<?php include('./partial_front/menu.php');
    
    $cat_id=$_GET['id'];
  
    $sql = "SELECT * FROM tbl_category where id=$cat_id";

    $res=mysqli_query($conn,$sql);

    $row=mysqli_fetch_assoc($res);

    $title = $row['title'];
    
?>

    <!-- Navbar Section Ends Here -->

    <!-- fOOD sEARCH Section Starts Here -->
    <section class="food-search text-center">
        <div class="container">
            
            <h2>Foods on <a href="#" class="text-white"><?php echo $title; ?></a></h2>

        </div>
    </section>
    <!-- fOOD sEARCH Section Ends Here -->



    <!-- fOOD MEnu Section Starts Here -->
    <section class="food-menu">
        <div class="container">
            <h2 class="text-center">Food Menu</h2>
         
            <?php    
            
            $sql2= "SELECT * FROM tbl_food where category_id=$cat_id";

            $res2 =mysqli_query($conn, $sql2);

            $count2=mysqli_num_rows($res2);

            if($res2==true)
            {
               //get value  in  count   
               if($count2>0)
               {
                   //data available
                   while($row2=mysqli_fetch_assoc($res2))
                   {
                       $id1=$row2['id'];
                       $title1=$row2['title'];
                       $price1=$row2['price'];
                       $description1=$row2['description'];
                       $image_name1=$row2['image_name'];
                       ?>

                    <div class="food-menu-box">
                    <div class="food-menu-img">
                        <img src="<?php echo SITEURL; ?>images/food/<?php echo $image_name1; ?>" alt="<?php echo $title1; ?>" class="img-responsive img-curve">
                    </div>
    
                    <div class="food-menu-desc">
                        <h4><?php echo $title1; ?></h4>
                        <p class="food-price"><?php echo $price1; ?></p>
                        <p class="food-detail">
                        <?php echo $description1; ?>
                        </p>
                        <br>
    
                        <a href="#" class="btn btn-primary">Order Now</a>
                    </div>
                </div>
                <?php
                   }
               }     
               else
               {
                   //data is not availble 
                   ?>
                   <div class="error">data is not availble</div>
                   <?php
               }
            }
            else
            {
                //query not executed 
                ?>
                <div class="error">query not executed</div>
                <?php

            }

            ?>
           

            <div class="clearfix"></div>

            

        </div>

    </section>
    <!-- fOOD Menu Section Ends Here -->

    <!-- social Section Starts Here -->
    <?php include('./partial_front/footer.php'); ?>