<?php include('partial/menu.php')?>



<div class="main_content">
    <div class="wrapper">
        <h1>update admin</h1>
        <?php
      $id = $_GET['id'];
       ?>
       <form action="" method="POST">
           <table>
               <tr>
                   <td>Full Name:</td>
                   <td><input type="text" name="full_name" placeholder="enter new  name"></td>
               </tr>
               <tr>
                   <td>Username:</td>
                   <td><input type="text" name="username" placeholder="enter new  username"></td>
               </tr>
               <tr>
                   <td colspan="2">
                       <input type="hidden" name="id" value="<?php echo $id; ?>">
                       <input type="submit" name="submit" value="update" class="btn_secondary">
                   </td>
               </tr>
           </table>
       </form>
    </div>
</div>
<?php 

if(isset($_POST['submit']))

    {
        //get value from input
        $id = $_POST['id'];
        $full_name = $_POST['full_name'];
        $username = $_POST['username'];
        
        //create sql query

        $sql = "UPDATE tbl_admin SET
        full_name ='$full_name',
        username ='$username'
        where id = '$id'
        ";

        //now executes query

        $res= mysqli_query($conn, $sql);

        //chech execution

        if($res==true)
        {
                        $_SESSION['update'] = "<div class='success'> admin updated</div>";
                        header("location:".SITEURL."admin/admin_manage.php");
        }
        else
        {
            $_SESSION['update'] = "not admin updated";
            header("location:".SITEURL."admin/admin_manage.php");
        }
    }
        ?>
<?php include('partial/footer.php')?>