<?php include('partial/menu.php')?>
<div class="main_content" >
  <div class="wrapper">
  <h1 >Add Admin </h1><br/>
  <form action=" "  method="POST">
    <table class="tbl_30">
      <tr > 
        <td>Full name</td>
        <td >
          <input type="text" name="full_name" placeholder="Enter your name">
      </td>
      </tr><br/>
      <tr > 
        <td>user name</td>
        <td>
          <input type="text" name="username" placeholder="Enter your username">
      </td>
      </tr>
      <tr > 
        <td>Password</td>
        <td >
          <input type="password" name="password" placeholder="Enter your name"><br/><br/>
      </td>
      </tr>
      <tr>
        <td colspan="4" class="text-center size"><input type ="submit" name="submit" value="adminName" class="btn_secondary"></td>
      </tr>
    </table>
</form>
</div>
</div>
<?php include('partial/footer.php')?>

<?php 
if(isset($_POST['submit']))
{
 $full_name=$_POST['full_name'];
 $username=$_POST['username'];
 $password=md5($_POST['password']);

// sql query to insert data

$sql= " insert into tbl_admin set 
full_name='$full_name',
username= '$username',
password= '$password'
";
$res= mysqli_query($conn, $sql) or die(mysqli_error());

if($res==true)
{
//echo "Data inserted succesfully";
$_SESSION['add']= "data inserted";
header("location:".SITEURL."admin/admin_manage.php");
}
else
{
//  echo "Data not inserted ";
  $_SESSION['add']= "not inserted";
header("location:".SITEURL."admin/add_admin.php");

}
}


?>