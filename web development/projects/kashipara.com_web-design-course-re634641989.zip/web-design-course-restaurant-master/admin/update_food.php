



<?php

include('partial/menu.php');
$id=$_GET['id'];

?>

<div class="main_content">
<div class="wrapper">
<h1>Add Food </h1> <br>
<?php

if(isset($_SESSION['upload'])){
    echo $_SESSION['upload'];
    unset($_SESSION['upload']);
    }

?>
<form action="" method="POST" enctype="multipart/form-data">
<?php
         $sql= "SELECT * FROM tbl_food where id='$id'";          
         $res=mysqli_query($conn, $sql);

         $count=mysqli_num_rows($res);
         ?>
<table>
    <tr>
        <td>Title:</td>
        <td><input type="text" name="title" placeholder="Enter your Title food  "></td> <br>
    </tr>

    <tr>
        <td>Discription:</td>
        <td><textarea name="description" cols="30" rows="4" placeholder="Description of food"></textarea></td>
    </tr>

    <tr>
        <td>Price:</td>
        <td><input type="number" name="price" ></td>
    </tr>
    <tr>
        <td>Current Image:</td>
        <td>
        <?php
         if($count>0)
         {
             //we have of category
             while($rows=mysqli_fetch_assoc($res))
             {
         // get category
           $id=$rows['id'];
           $current_image=$rows['image_name'];
          ?>
           
           <img src="<?php echo SITEURL; ?>images/food/<?php echo $current_image; ?>" alt="current image" width="130px">
           <?php

             }
             
         }
         else
         {

             //we do not have category
           ?>
        <td>No found image</td>
           <?php

         }
        
        ?></td>
    </tr>
<tr>
    <td>Select Image:</td>
    <td><input type="file" name="image" value=""></td>
</tr>

    <tr>
    <td>Category:</td>
    <td><select name="category">
        
<?php

$sql= "SELECT * FROM tbl_food where id='$id'";          
$res=mysqli_query($conn, $sql);

$count=mysqli_num_rows($res);

         if($count>0)
         {
             //we have of category
             while($rows=mysqli_fetch_assoc($res))
             {
         // get category
           $id=$rows['id'];
           $title=$rows['title'];
          ?>
           
            <option value="<?php echo $id;?> "><?php echo $title;?></option>
           <?php

             }
             
         }
         else
         {
             //we do not have category
           ?>
<option value="0">No Category found</option>
           <?php

         }
        
        ?>
        
    </select></td>
    </tr>
    <tr>
        <td>Feaured:</td>
        <td>
            <input type="radio" name="featured" value="Yes">Yes
            <input type="radio" name="featured" value="No">No
       </td>
    </tr>

    <tr>
        <td>Active:</td>
        <td>
            <input type="radio" name="active" value="Yes">Yes
            <input type="radio" name="active" value="No">No
       </td>
    </tr>

    <tr> 
        <td class="text-center"><input type="submit" name="submit" value="add food" class="btn_secondary"></td>
    </tr>
</table>


</form>
<?php

if(isset($_POST['submit']))
{
    //add food to database

    //get data from input
   echo $title=  $_POST['title'];
   echo $description=  $_POST['description'];
   echo $price=  $_POST['price'];
    echo $category=  $_POST['category'];

    //check whether radio button for featured and active checked or not

    if(isset($_POST['featured']))
    {
    // get checked featured get
    $featured=$_POST['featured'];
    }
    else
    {
     //revert message as not checked
     $featured="No";
    }
    if(isset($_POST['active']))
    {
      //get checked active
      $active=$_POST['active'];
    }
    else
    {
      //revert no message
      $active="No";
    }

    //upload image if selected
    //chech whether the image is select or not 
   print_r($_FILES['image']);
   // die();
   if(isset($_FILES['image']['name']))
    {
   //get details of selected image
       $image_name=$_FILES['image']['name'];

       //chech whether the image is select or not 
       
           //image is selected
           //and here remname image get extention for rename
             $ext=end(explode('.', $image_name));

             //create new name
             $image_name="food_name_".rand(000,999).".".$ext;

             //upload image
             //get source pathn and destination

             //source path is current location image
             $src=$_FILES['image']['tmp_name'];

             //get destination path of image
             $dst = "../images/food/".$image_name;

             //upload image
             $upload=move_uploaded_file($src,$dst);


             //check image uploaded or not

             if($upload==false)
             {
                 // message not uploded
                  $_SESSION['upload'] =" <div class='error'>Failed to upload image</div>";

                   //redirect with the message
                   header('location:'.SITEURL.'admin/update_food.php');
                   die();
             }
              else
              {
                  $image_name;
              }
    }
    else
    {
   //set default value 
   $image_name="not set";
    }

    //insert into database
    //create query for insert  data
   $sql2="UPDATE tbl_food SET
    title='$title',
    description='$description',
    price='$price',
    image_name='$image_name',
    category_id='$category',
    featured='$featured',
    active='$active' where id='$id'";

    //now execute it
    $res2=mysqli_query($conn, $sql2);

    //check is it executed
    if($res2==true)
    {
        //message as success in session
        $_SESSION['add']="<div class='success'>food Updated successfully</div>";
        unlink('../images/food/'.$current_image);
        //and redicet to manage food
        header('location:'.SITEURL.'admin/manage_food.php');
    }
    else
    {
        //message as failed in session
        $_SESSION['add']="<div class='error'>food not updated </div>";

        //and redicet to add food
        header('location:'.SITEURL.'admin/manage_food.php');
  
    }
    }

    //redirect with message to manage food

?>
</div>
</div>

<!--menu content end -->
<?php include('partial/footer.php') ?>

