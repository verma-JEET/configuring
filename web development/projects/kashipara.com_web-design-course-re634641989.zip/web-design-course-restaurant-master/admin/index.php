<?php include('partial/menu.php')?>

  <!--menu content starts -->
  <div class="main_content" >
  <div class="wrapper">
  <h1 >Dashboard +</h1><br/>
    <br>
   <?php 
   
   $sql ="SELECT * FROM tbl_category";
   $res=mysqli_query($conn,$sql);
   $count=mysqli_num_rows($res);

   $sql1 ="SELECT * FROM tbl_food";
   $res1=mysqli_query($conn,$sql1);
   $count1=mysqli_num_rows($res1);

   $sql2 ="SELECT * FROM tbl_order";
   $res2=mysqli_query($conn,$sql2);
   $count2=mysqli_num_rows($res2);

   $sql3 ="SELECT sum(total) AS total FROM tbl_order ";
   $res3=mysqli_query($conn,$sql3);
   $rows=mysqli_fetch_assoc($res3);
   $total=$rows['total'];

   ?>
   <div class="col-4 text-center"><h1><?php echo $count; ?></h1>
  Category</div>
<div class="col-4 text-center "><h1><?php echo $count1; ?></h1>
  food</div>
  <div class="col-4 text-center "><h1><?php echo $count2; ?></h1>
  Order</div>
<div class="col-4 text-center"><h1><?php echo $total; ?></h1>
  Revenue</div></div>

<div class="clearfix" ></div>
    </div> 
   
    </div>
 <!--menu content end -->
<?php include('partial/footer.php') ?>