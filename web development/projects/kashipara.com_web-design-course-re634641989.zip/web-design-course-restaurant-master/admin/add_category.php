<?php include('partial/menu.php')?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Category</title>
    <link rel="stylesheet" href="./admincss/admin.css">
</head>
<body><br>
<div class="text-center">
    <h1 >Add Category</h1> <br>
   <?php
   
   if(isset($_SESSION['cadd']))
          {
              echo $_SESSION['cadd'];
              unset ($_SESSION['cadd']);
        
            }

            if(isset($_SESSION['upload'])){
            echo $_SESSION['upload'];
            unset($_SESSION['upload']);
            }
            ?>
    <br>
<form action="" method="POST" enctype="multipart/form-data">
    <table >
        <tr>
            <td>
              Title:
            </td>
            <td>
            <input type="text" name="title"> </td><br>
        </tr>
        <tr>
            <td>
              Select image:
            </td>
            <td>
            <input type="file" name="image"> </td><br>
        </tr>
        <tr>
            <td>
              Featured:
            </td>
            <td>
            <input type="Radio" name="feature" value="Yes">Yes
            <input type="Radio" name="feature" value="No">No
            </td>
            </tr>

            </tr>
        <tr>
            <td>
              Active:
            </td>
            <td>
            <input type="Radio" name="active" value="Yes">Yes
            <input type="Radio" name="active" value="No">No <br>
            </td>
            </tr>
            <tr>
                <td>
                    <input type="submit" name="submit" value="add Category" class="btn_secondary"><br> <br>

                </td>
            </tr>
             </table>
             </form>
</div>
<?php    

if(isset($_POST['submit']))
{

  $title= $_POST['title'];
    if(isset($_POST['feature']))
    {
       $feature=$_POST['feature'];
    }
    else
    {
        $feature="No";
    }
    if(isset($_POST['active']))
    {
        $active=$_POST['active'];
    }
    else
    {
        $active="No";
    }

    //check image selection

   // print_r($_FILES['image']);
   // die();

   if(isset($_FILES['image']['name']))
   {

    //upload file need image name and source path  and destination path
       $image_name=$_FILES['image']['name'];

       //Auto rename to image 
       //get extension of image
       $ext=end(explode('.' , $image_name));

       //rename image
       $image_names="food_category_".rand(000,999). ".".$ext;

       $source_path=$_FILES['image']['tmp_name'];

       $destination_path="../images/category/".$image_names;

       $upload= move_uploaded_file($source_path,$destination_path);

       if($upload==false)
       {
           //set message
           $_SESSION['upload']="<div class='error'>Failed to upload image</div>";

           //redirect now
         header('location:'.SITEURL.'admin/add_category.php');
         die();
       }
       else
       {
        $image_names; 
       }

   }
$sql ="INSERT INTO tbl_category set 
title='$title',
image_name='$image_names', 
featured='$feature',
 active='$active'";
$res=mysqli_query($conn, $sql);

if($res==true)
{
    $_SESSION['cadd']="<div class='success'>Category added succesfully</div>";
    header('location:'.SITEURL.'admin/manage_category.php');
}
else
{
$_SESSION['cadd']="<div class='success'>Category not added</div>";
header('location:'.SITEURL.'admin/add_category.php');
}

}
?>
</body>
</html>


<?php include('partial/footer.php') ?>