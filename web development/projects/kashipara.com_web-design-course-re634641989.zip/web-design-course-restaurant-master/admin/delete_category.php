<?php

include ('./Config/connection.php');
//include('./admincss/admin.css');
if(isset($_GET['id']) && isset($_GET['image_name']))
{
$current_image=$_GET['image_name'];
$id=$_GET['id'];
  
}


//write query for delete

$sql= "DELETE FROM tbl_category where id=$id";

//now  execute query
$res=mysqli_query($conn, $sql);

//check is it executed
if($res==true)
{
    //create sesion for msg 
    $_SESSION['category_delete']="<div class='success'>Deleted succesfully</div>";

    $path='../images/category/'.$current_image;
    unlink($path);
    //not redirect session to category page
    header('location:'.SITEURL.'admin/manage_category.php');
    
}
else
{
    //session created
    $_SESSION['category_delete']="<div class='success'>Not delete</div>";

    //not redirect session to category page
    header('location:'.SITEURL.'admin/manage_category.php');  
}

?>