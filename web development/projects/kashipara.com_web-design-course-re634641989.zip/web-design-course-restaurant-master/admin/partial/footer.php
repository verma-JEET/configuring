
<!--menu footer starts -->
<div class="footer text-center" >
  <div class="wrapper">
   All Right reseved design by <a href="#">vinod</a> 
    </div>
</div>
 <!--menu footer end -->
</body>
</html>