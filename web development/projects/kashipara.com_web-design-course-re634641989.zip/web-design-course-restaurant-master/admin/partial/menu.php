<?php
 include('./Config/connection.php') ;
 include('./Config/log_check.php') ;

 ?>
 <?php
    
    if(isset($_SESSION['login']))
    {
        echo $_SESSION['login'];  
       // unset($_SESSION['login']);
    }
 

    
    ?>
 
<!DOCTYPE html>
<html lang="en">
<link rel="stylesheet" href="admincss/admin.css">
<head>
    <title>food order website home page</title>
    <meta charset="UTF-8">
    <!-- Important to make website responsive -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
</head>
<body>
 <!--menu section starts -->
 <div class="menu text-center">
   <div class="wrapper">
    
<ul>
  <li><a href="index.php">home</a> </li>
  <li><a href="admin_manage.php">Admin manager</a> </li>
  <li><a href="manage_category.php">Category</a> </li>
  <li><a href="manage_food.php">food</a> </li>
  <li><a href="manage_order.php">order</a> </li>
  <li><a href="logout.php">Logout</a></li>
</ul>
 </div>
 </div>
 
 <!--menu section end -->
 
