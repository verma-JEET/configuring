<?php

include ('./Config/connection.php');

//here to get id value of sr. number
$id = $_GET['id'];

//sql query to delete admin
$sql = "delete from tbl_admin where id=$id";

//now execute qery
$res =mysqli_query($conn, $sql);

if($res==true)
{
  //  echo "success";

  //create  session variable to display msg
  $_SESSION['delete']="<div class='success'> admin delete succesfully</div>";
  header('location:'.SITEURL.'admin/admin_manage.php');
}
else
{
    //echo "not succes";

    //create  session variable to display msg
  $_SESSION['delete']="<div class ='error'>admin not deleted</div>";
  header('location:'.SITEURL.'admin/admin_manage.php');
}

?>