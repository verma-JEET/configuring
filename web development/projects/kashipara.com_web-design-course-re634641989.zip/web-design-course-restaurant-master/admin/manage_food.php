<?php include('partial/menu.php')?>

  <!--menu content starts -->
  <div class="main_content" >
  <div class="wrapper">
  <h1 >Food </h1>
  <br/>
  <?php

if(isset($_SESSION['add'])){
    echo $_SESSION['add'];
    unset($_SESSION['add']);
    }
    if(isset($_SESSION['delete'])){
        echo $_SESSION['delete'];
        unset($_SESSION['delete']);
        }

?>
  <br>
  <a href="add_food.php" class="btn_primary">Add Food</a>
  
  <table class="tbl_full">
      <tr>
          <th>Sr.</th>
          <th>Title</th>
          <th> Discription </th>
          <th>Price</th>
          <th>Select image</th>
          <th>Category</th>
          <th>Featured</th>
          <th>Active</th>
          <th>Action</th>
      </tr>
          <?php  
          //create query
          $sql="SELECT * FROM tbl_food";
           
           //executes query
           $res=mysqli_query($conn,$sql);

           //count executed query
           $count=mysqli_num_rows($res);

           if($count>0)
           {
               //display page
               $sn=1;
               while($rows=mysqli_fetch_assoc($res))
               {
                $id=$rows['id'];
                 $title=$rows['title'];
                 $description=$rows['description'];
                 $price=$rows['price'];
                 $image_name=$rows['image_name'];
                 $category_id=$rows['category_id'];
                 $featured=$rows['featured'];
                 $active=$rows['active'];
              

          


          ?><tr>
          <td><?php echo $sn++ ?></td>
          <td><?php  echo  $title; ?></td>
          <td><?php echo $description; ?></td>
          <td><?php echo $price; ?></td>
          <td>
              <?php 

              if($image_name!="")
              {
                  ?>
                  <img src="<?php echo SITEURL; ?>images/food/<?php echo $image_name;?> " width="100px">
                  <?php
              }
              else
              {
                echo "<div class='error'>image is not present</div>";
              }
          
          ?></td>
          <td><?php echo $category_id; ?></td>
          <td><?php echo $featured; ?></td>
          <td><?php echo $active; ?></td>
          <td>
          <a href="<?php echo SITEURL; ?>admin/update_food.php?id=<?php echo $id;  ?>" class="btn_secondary">Update Food</a>
          <a href="<?php echo SITEURL; ?>admin/delete_food.php?id=<?php echo $id; ?>&image_name=<?php echo $image_name; ?>" class="btn_Dangers">Delete Food</a>
          </td>
      </tr>
      <?php  }
           }
           else
           {
               ?>
               
                  <tr>
              <td colspan="9" ><div class="error">No category added</div></td>

          </tr>
          <?php
           }
      ?>
  </table>

<div class="clearfix" ></div>
    </div> 
   
    </div>
 <!--menu content end -->
<?php include('partial/footer.php') ?>