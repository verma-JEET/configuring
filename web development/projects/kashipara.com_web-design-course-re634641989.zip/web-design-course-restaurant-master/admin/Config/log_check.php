<?php
//authorization
//check user login or not
 if(!isset($_SESSION['user'])) // if user not login
{
 //redirect to login
 $_SESSION['no-login-message']= "<div class='error'>plz login admin panel first</div>";
 header('location:'.SITEURL.'admin/login.php');

}

?>