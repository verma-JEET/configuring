<?php 
session_start();

//create constan to not repeat value
define('SITEURL','http://localhost/web-design-course-restaurant-master/');
define('LOCALHOST','localhost');
define('DB_USERNAME','root');
define('DB_PASSWORD','');
define('DB_NAME','food-order');
$conn= mysqli_connect('localhost','root','');
$db_select= mysqli_select_db($conn, DB_NAME) or die(mysqli_error());

?>