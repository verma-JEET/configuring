<?php include('partial/menu.php')?>

  <!--menu content starts -->
  <div class="main_content" >
  <div class="wrapper">
  <h1 >Order </h1> 
 <br/>
  <a href="#" class="btn_primary">Add Order</a>
  <table class="tbl_full">
      <tr>
          <th>Sr.N.</th>
          <th>Food</th>
          <th> Price</th>
          <th>Total Price</th>
          <th>Quantity</th>
          <th>Order Date</th>
          <th>Status</th>
          <th>Customer</th>
          <th>Contact</th>
          <th>Email</th>
          <th>Address</th>
          <th>Action</th>
      </tr>
      
         <?php
  
           $sql= " SELECT * FROM tbl_order order by id ";
           $res=mysqli_query($conn, $sql);
           $count= mysqli_num_rows($res);
           if($res==true)
           {
              //query executed
              if($count>0)
              {
                  //get value
                  while($rows=mysqli_fetch_assoc($res))
                  {      
                      $id=$rows['id'];
                      $food=$rows['food'];
                      $price=$rows['price'];
                      $total=$rows['total'];
                      $qty=$rows['qty'];
                      $date=$rows['order_date'];
                      $status=$rows['status'];
                      $cust_name=$rows['cust_name'];
                      $cust_contact=$rows['cust_contact'];
                       $cust_email=$rows['cust_email'];
                      $cust_address=$rows['cust_address'];

                      ?>
                      <tr>
                    <td><?php echo $id; ?></td>
                    <td><?php echo $food; ?></td>
                    <td><?php echo $price; ?></td>
                    <td><?php echo $total; ?></td>
                    <td><?php echo $qty; ?></td>
                    <td><?php echo $date; ?></td>
                    <td><?php echo $status; ?></td>
                    <td><?php echo $cust_name; ?></td>
                    <td><?php echo $cust_contact; ?></td>
                    <td><?php echo $cust_email; ?></td>
                    <td><?php echo $cust_address; ?></td>
                   
                    <td>
                    <a href="#" class="btn_secondary">update admin</a>
                    <a href="#" class="btn_Dangers">Delete admin</a>
                    </td> 
                    <?php
                  }
              }
              else
              {
                  //data is not have
              }
           }
           else
           {
               //query not  executed
           }
                 ?> 

          
      </tr>
   
     
  </table>
   
<div class="clearfix" ></div>
    </div> 
   
    </div>
 <!--menu content end -->
<?php include('partial/footer.php') ?>