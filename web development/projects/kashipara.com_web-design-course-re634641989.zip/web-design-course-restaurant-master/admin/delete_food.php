<?php  
include ('./Config/connection.php');

//get the id from other page
 $id=$_GET['id'];
  $current_image=$_GET['image_name'];

//create query for delete
$sql ="DELETE FROM tbl_food where id=$id";

//execute query
$res=mysqli_query($conn, $sql);

if($res==true)
{
    //message as sussecc
    $_SESSION['delete']="<div class='success'>Food Deleted successfully</div>";
    unlink('../images/food/'.$current_image);

    //redirect page to manage food
    header('location:'.SITEURL.'admin/manage_food.php');
}
else
{
    //message as not delete
    $_SESSION['delete']="<div class='success'>Food Not Deleted successfully</div>";

    //redirect page to manage food
    ('location:'.SITEURL.'admin/manage_food.php');
}

?>