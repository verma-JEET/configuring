<?php include('partial/menu.php')?>

  <!--menu content starts -->
  <div class="main_content" >
  <div class="wrapper">
  <h1 >Admin Dashboard </h1>
  <br/>
  <?php if(isset($_SESSION['add']))
  {
      echo $_SESSION['add'];
      unset($_SESSION['add']);
  }
  if(isset($_SESSION['delete']))
  {
      echo $_SESSION['delete'];
      unset ($_SESSION['delete']);

    }
    if(isset($_SESSION['update']))
    {
        echo $_SESSION['update'];
        unset ($_SESSION['update']);
  
      }
      if(isset($_SESSION['user-not-found']))
      {
          echo $_SESSION['user-not-found'];
          unset ($_SESSION['user-not-found']);
    
        }
        if(isset($_SESSION['change_password']))
        {
            echo $_SESSION['change_password'];
            unset ($_SESSION['change_password']);
      
          }
         

         

    
  ?>
  <br/>
  <br/>
  <a href="add_admin.php" class="btn_primary">add admin</a>
  <table class="tbl_full">
      <tr>
          <th>
              Sr.
          </th>
          <th>
              full_name
          </th>
          <th>
              Username
          </th>
          <th>
              Action
          </th>
      </tr>
<?php
// query to get data
$sql= "select * from tbl_admin";

//execute the query
$res = mysqli_query($conn, $sql);

//check is query executed
if($res==true)
{
    //count rows to check whether we have data
    $count = mysqli_num_rows($res);//function to get all row in database
$sn=1;
    //check the num of row
    if($count>0)
    {
// msg we have data
while($row=mysqli_fetch_assoc($res))
{
    // loop to get all data from database
    //loop will run as long as we have data in database

    //get individual data
    $id= $row['id'];
    $full_name = $row['full_name'];
    $username = $row['username'];

    //display data in table
    ?>



<tr>
    <td><?php echo $sn++; ?></td>
    <td><?php echo $full_name; ?></td>
    <td><?php echo $username; ?></td>
    <td>
          <a href="<?php echo SITEURL; ?>admin/update_admin.php?id=<?php echo $id; ?>" class="btn_secondary">update admin</a>
          <a href="<?php echo SITEURL; ?>admin/delete_admin.php?id=<?php echo $id; ?>" class="btn_Dangers">Delete admin</a>
          <a href="<?php echo SITEURL; ?>admin/update_password.php?id=<?php echo $id; ?>" class="btn_primary">Change password</a>
       
        </td>
</tr>

<?php
}
}
}
?>
</table>
   
<div class="clearfix" ></div>
    </div> 
   
    </div>
 <!--menu content end -->
<?php include('partial/footer.php') ?>