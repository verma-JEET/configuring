<?php include('partial/menu.php')?>
<div class="main_content">
    <div class="wrapper">
        <h1>Change password</h1>
        <?php 
         $id = $_GET['id'];
         ?>
         
         
       <form action=" " method="POST">
        <table>
            <tr>
                <td>CURRENT PASSWORD:</td>
                <td>
                    <input type="password" name="current_pwd" placeholder="old password" required>
                </td>
            </tr>
            <tr>
                <td>NEW PASSWORD:</td>
                <td>
                    <input type="password" name="new_pwd" placeholder="enter new password" required>
                </td>
            </tr>
            <tr>
                <td> CONFIRM PASSWORD:</td>
                <td>
                    <input type="password" name="confirm_pwd" placeholder="confirm password" required>
                </td>
            </tr>
            <tr>
                   <td colspan="2">
                       <input type="hidden" name="id" value="<?php echo $id; ?>">
                       <input type="submit" name="submit" value="change password" class="btn_secondary">
                   </td>
        </table>
        </form>
    </div>
</div>

<?php 

if(isset($_POST['submit']))
{
     //get value from input
     $id = ($_POST['id']);
     $current_pwd = md5($_POST['current_pwd']);
     $new_pwd = md5($_POST['new_pwd']);
     $confirm_pwd =md5( $_POST['confirm_pwd']);

     //check current password is correct

     $sql = "SELECT * FROM tbl_admin where id='$id' AND password = '$current_pwd' ";

      //now executes query
      $res= mysqli_query($conn, $sql);

         //chech execution

        
         if($res==true)
          {
             $count = mysqli_num_rows($res);
              if($count==1)
              {
                   if($new_pwd==$confirm_pwd)
                         {
                     //  user exist and password can change
                   
                       $sql1= "UPDATE tbl_admin SET password = '$new_pwd' where id =$id";
                       
                       $res1= mysqli_query($conn, $sql1);
                           if($res1==true)
                           {
                            $_SESSION['change_password'] ="Password succesfully changed";
                            header("location:".SITEURL."admin/admin_manage.php");
                           }
                          else
                         {
                     //user not exist set message and redirect
                        $_SESSION['password-not-found'] ="user not found";
                        header("location:".SITEURL."admin/admin_manage.php");
                         }
                        }
                        else
                        {   
                            $_SESSION['user-not-found']="user not found";
                            header("location:".SITEURL."admin/admin_manage.php");
                        }
                    }
                }
                else
                {
                    echo "query not executed";
                }
         }
        
        
 
?>
<?php include('partial/footer.php')?>