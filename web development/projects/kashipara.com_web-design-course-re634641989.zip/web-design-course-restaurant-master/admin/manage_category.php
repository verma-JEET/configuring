<?php include('partial/menu.php')?>

  <!--menu content starts -->
  <div class="main_content" >
  <div class="wrapper">
  <h1 >category </h1>
  <br/>
  <?php
 if(isset($_SESSION['cadd']))
 {
     echo $_SESSION['cadd'];
     unset ($_SESSION['cadd']);

   }
   if(isset($_SESSION['category_delete']))
   {
       echo $_SESSION['category_delete'];
       unset ($_SESSION['category_delete']);
  
     }


  ?>
  
  <br>

  <a href="<?php echo SITEURL; ?>admin/add_category.php" class="btn_primary">Add Category</a>
  <table class="tbl_full">
      <tr>
          <th>Sr.</th>
          <th>Title</th>
          <th> Image</th>
          <th> Featured</th>
          <th>Active</th>
          <th>Actions</th>
      </tr>
      <?php

      $sql="SELECT * FROM tbl_category";

      $res=mysqli_query($conn, $sql);

      $count= mysqli_num_rows($res);

      if($count>0)
      { $sn=1;
         while($rows= mysqli_fetch_assoc($res))
         {
             $id=$rows['id'];
             $Title=$rows['title'];
             $image_name=$rows['image_name'];
             $featured=$rows['featured'];
             $active=$rows['active'];

             ?>
              <tr>

          <td><?php echo $sn++ ?></td>
          <td><?php echo  $Title; ?></td>
          <td>
         <?php 
          if($image_name!=="")
          {
              //display image
            ?>
             <img src="<?php echo SITEURL; ?>images/category/<?php  echo $image_name; ?>" width="100px">

           <?php
          }
          else
          {
              //image not present
              
              echo "<div class='error'>image is not present</div>";
             
          }
          ?>
          </td>
          <td><?php echo $featured; ?></td>
          <td><?php echo  $active; ?></td>
          <td>
          <a href="<?php echo SITEURL; ?>admin/update_category.php?id=<?php echo $id;  ?>&image_name=<?php echo $image_name; ?>" class="btn_secondary">update Category</a>
          <a href="<?php echo SITEURL;?>admin/delete_category.php?id=<?php echo $id; ?> &image_name=<?php echo $image_name;  ?>" class="btn_Dangers">Delete Category</a>
          </td>
      </tr>
             <?php
         }
      }
      else
      {
          //we do not have data
          //we display the message inside data
          
          ?>

          <tr>
              <td colspan="6" ><div class="error">No category added</div></td>

          </tr>    

<?php
      }

      ?>
     
     
  </table>
   
<div class="clearfix" ></div>
    </div> 
   
    </div>
 <!--menu content end -->
<?php include('partial/footer.php') ?>