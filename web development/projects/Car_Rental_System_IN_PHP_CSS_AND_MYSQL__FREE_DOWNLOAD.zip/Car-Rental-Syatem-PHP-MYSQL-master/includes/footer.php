	<li class="about">
					<p>projectworlds team is an organized company that rents cars and other vehicles to clients at lower costs. We we are here to serve every indian Citizen</p>
					<ul>
						<li><a href="http://facebook.com/projectworldsin" class="facebook" target="_blank"></a></li>
						<li><a href="http://twitter.com/projectworlds32" class="twitter" target="_blank"></a></li>
						<li><a href="http://plus.google.com/projectworlds32" class="google" target="_blank"></a></li>
						<li><a href="#" class="skype"></a></li>
					</ul>
				</li>
			</ul>
		</div>

		<div class="copyrights wrapper">
			Copyright &copy; <?php echo date("Y")?> All Rights Reserved | Designed by <a href= "http://projectworlds.in/">projectworlds.</a>
		</div>
	</footer><!--  end footer  -->
	
</body>
</html>