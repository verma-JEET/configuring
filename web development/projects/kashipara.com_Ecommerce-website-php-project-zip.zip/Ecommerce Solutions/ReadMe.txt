Title: ecommercesolutions
Description: ecommerce php mysql script

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
