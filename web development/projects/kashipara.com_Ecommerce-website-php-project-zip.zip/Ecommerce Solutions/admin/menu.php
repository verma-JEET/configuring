<style>
body{
background: #D6DFF7;
font-family: Verdana; color: #3366CC; text-decoration: none; font-size: 8pt
}
.bordi{
/*
width:200px;
height:20px;
border: 1px solid #DDDDDD;
background-color: #F7F7F7;
padding:2px;
*/
}
</style>

<img border="0" src="images/house.gif">        <a href="desk.php" target="main">Home</a><br>
<img border="0" src="images/bricks.gif">       <a href="sel_prodotti.php" target="main">Prodotti</a><br>
<img border="0" src="images/folder_table.gif"> <a href="sel_categorie.php" target="main">Categorie</a><br>
<img border="0" src="images/group.gif">        <a href="sel_utenti.php" target="main">Utenti</a><br>
<img border="0" src="images/cart_put.gif">     <a href="sel_ordini.php" target="main">Ordini</a><br>
<img border="0" src="images/money.gif">        <a href="sel_pagamenti.php" target="main">Pagamenti</a><br>
<img border="0" src="images/package.gif">      <a href="sel_spedizioni.php" target="main">Spedizioni</a><br>
<img border="0" src="images/bricks.gif">      <a href="mod_configurazione.php" target="main">Configurazione</a><br>
<img border="0" src="images/edit.png">      <a href="mod_template.php" target="main">Templates</a><br>
<img border="0" src="images/email.gif">        <a href="sel_email.php" target="main">Newsletter</a><br>
<img border="0" src="images/cog_edit.gif">     <a href="opzioni.php" target="main">Opzioni</a><br>
<img border="0" src="images/money.gif">        <a href="sel_pagine_HTML.php" target="main">Pagine aggiuntive</a><br>
<img border="0" src="images/chart.gif">        <a href="sel_stat.php" target="main">Statistiche</a><br>
<img border="0" src="images/2.png">        <a href="backup.php" target="main">Backup</a><br>
<img border="0" src="images/star.gif">        <a href="ripristino.php" target="main">Ripristino</a><br>
<br>
<img src="images/exit.gif" border=0> <a href="logout.php" target="main">Esci</a>   <br><br>
<center>Powered by <a href="http://www.ecommercesolutions.it" target="_blank" title="semplice ecommerce php mysql">ecommercesolutions.it</a></center>
