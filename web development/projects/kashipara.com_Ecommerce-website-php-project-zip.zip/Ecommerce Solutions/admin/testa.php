<base target="main">
<body background="images/testa.jpg" style="font-family: Tahoma; color: #FFFFFF; font-size: 24 pt; font-weight: bold; font-style: oblique; margin-top: 0; margin-right: 0; margin-bottom: 0">
<table border="0" width="100%" height="100%">
        <tr>
                <td align="right" valign="bottom" style="font-family: Verdana; color: #FFFFFF; font-size: 7pt; font-weight: normal">
                Oggi <?echo date("d M Y");?>
                </td>
        </tr>
</table>