// UK lang variables

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Direction left to right (Alt-.)',
directionality_rtl_desc : 'Direction right to left (Alt-,)'
});
