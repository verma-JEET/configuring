
<html>
<head>
<title>Phone Book</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div id = "main">
  <h1> Phone Book</h1>
  <?php 
  
  include_once 'menu-main.php';
  ?>
  
<p class="cpara"> You can contact me without any hesitation.</p>
<h2 class="chead">Personal cell no</h2>
<p class="cpara">+923334729741</p> 
 <h2 class="chead">Whatsapp no</h2>
<p class="cpara">+923334729741</p> 
  <h2 class="chead">You can directly contact me via email</h2>
<p class="cpara">bakhtiar.wazir1@gmail.com</p>
</div>
</body>
</html>
